interface Add1Reply {
    void reply();
}
