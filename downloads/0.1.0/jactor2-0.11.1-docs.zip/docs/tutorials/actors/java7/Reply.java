interface Reply<RESPONSE_TYPE> {
    void response(RESPONSE_TYPE _value);
}
