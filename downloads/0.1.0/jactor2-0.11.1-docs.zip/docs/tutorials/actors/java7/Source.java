public interface Source {
    void depositCompletion(boolean success);
    void transferCompletion(boolean success);
}
